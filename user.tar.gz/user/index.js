const fetchData = (function () {
    fetch('http://172.17.0.2/api/items/read.php')
        .then((response) => response.json())
        .then((json) => {
            const tbody = document.querySelector('#tbody');
            tbody.innerHTML = `${json.items.map((user) => `<tr>
                <td>${user.id}</td>
                <td>${user.name}</td>
                <td>${user.description}</td>
            </tr>`).join('')}`;
        });
})();

window.addEventListener('load', fetchData);